# GCC compilation command

```bash
gcc window.c -o window.exe -I include/ -L lib/ -lraylib -lopengl32 -lgdi32 -lwinmm
```
